import java.util.Scanner;

public class addition {
    public static void main(String[] args) {
        Scanner obj=new Scanner(System.in);
        Integer a,b;
        System.out.println("Enter 2 numbers for addition");
        a=obj.nextInt();
        b=obj.nextInt();
        System.out.println("Sum of 2 numbers is :" + (a+b));
        obj.close();
    }  
}