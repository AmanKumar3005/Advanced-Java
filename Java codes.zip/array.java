public class array {
    public static void main(String[] args) {
        int a1[]=new int[5];
        for(int i=0;i<5;i++)
        {
            a1[i]=i;
        }
        for(int i=0;i<5;i++)
        {
            System.out.println("Numbers :" + a1[i]);
        }
    }   
}
