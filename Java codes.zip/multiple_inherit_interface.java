interface A{
    void print();
}
class B implements A{
    public void print(){
        System.out.println("Hi!");
    }
}
public class multiple_inherit_interface {
    public static void main(String[] args) {
        B obj =new B();
        obj.print();
    }
    
}
