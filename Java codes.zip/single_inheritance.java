class p1{
    void house(){
        System.out.println("I have house");
    }
}
class c1 extends p1{
    void car(){
        System.out.println("Audi");
    }
}

public class single_inheritance {
    public static void main(String[] args) {
        c1 obj=new c1();
        obj.car();
        obj.house();
        
    }
    
}
