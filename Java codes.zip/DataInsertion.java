
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DataInsertion extends Frame implements ActionListener {
  Button b1, b2;
  TextField t1, t2;
  Label l1, l2;

  DataInsertion() {
    setVisible(true);
    setSize(400, 400);
    b1 = new Button("Insert");
    b2 = new Button("Delet");
    t1 = new TextField(20);
    l1 = new Label("Enter the name");
    setLayout(new FlowLayout());
    add(l1);
    add(t1);
    add(b1);
    add(b2);

    b1.addActionListener(this);
    b2.addActionListener(this);
  }

  public void actionPerformed(ActionEvent ae) {
    System.out.println("Debug-1");
    if (ae.getSource() == b1) {
      String name = t1.getText();
      try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "ansh1311"); // here
                                                                                                              // sonoo
                                                                                                              // is
                                                                                                              // database
                                                                                                              // name,
                                                                                                              // root is
                                                                                                              // username
                                                                                                              // and
                                                                                                              // password
        Statement stmt = con.createStatement();
        // String sql = "insert into insertion values ('" +name+ "');";
        stmt.executeUpdate("insert into table1 values ('" + name + "');");
        con.close();
      }

      catch (ClassNotFoundException | SQLException e) {
        System.out.println(e);
      }
    }
    if (ae.getSource() == b2) {
      dispose();
    }

  }

  public static void main(String args[]) {
    DataInsertion di = new DataInsertion();
  }
}