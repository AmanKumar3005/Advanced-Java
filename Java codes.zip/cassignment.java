import java.util.Scanner;


public class cassignment {
    public static void main(String[] args) {
        System.out.println("Enter the availability status of printer: ");
        Scanner sc=new Scanner(System.in);
        Boolean b=sc.nextBoolean();
        try{
            if(b==false){
                throw new Exception("Printer not available");
            }
            else{
                System.out.println("Printer available");
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}
