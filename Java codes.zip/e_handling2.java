public class e_handling2 {
    public static void main(String[] args) {
        try{
            int data =50/0;
        }
        catch(ArithmeticException e){
            System.out.println(e);
        }
        catch(ArrayIndexOutOfBoundsException e){
            System.out.println(e);

        }
        finally{
            System.out.println("VIT Bhopal");
        }
    }
    
}
//Chexk for the printer if it is available then print available otherwise not available
