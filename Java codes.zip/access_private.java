 class access_private {
    private void msg(){
        System.out.println("hello");
    }
    public static void main(String[] args) {
        access_private obj=new access_private();
        obj.msg();   
    }   
}