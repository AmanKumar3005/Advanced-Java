
class emp implements java.io.Serializable{
    private int id;
    private String dept;
    emp(){

    }
    public void setId(int id){
        this.id=id;
    }
    public void setdept(String dept){
        this.dept=dept;
    }
    public int getId(){
        return id;
    }
    public String getdept(){
        return dept;
    }
}
public class revisionbean {
    public static void main(String[] args) {
        emp obj=new emp();
        obj.setId(11016);
        obj.setdept("CSE");
        int a =obj.getId();
        System.out.println(a);
        String s=obj.getdept();
        System.out.println(s);
    }  
}