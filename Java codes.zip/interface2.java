
//Single interface with multiple classes 
interface shape{
    void draw();
}

class circle implements shape{
    public void draw(){
        System.out.println("Draw circle");
    }
}
class square implements shape{
    public void draw(){
        System.out.println("Draw square");
    }
}
public class interface2 {
    public static void main(String[] args) {
        shape obj =new circle();
        shape obj1=new square();
        obj.draw();
        obj1.draw();
    }
    
}
