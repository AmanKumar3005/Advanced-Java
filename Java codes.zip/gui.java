//How to take data from text field connectivity frontend with database 
//Swing
//AWT
import java.awt.*;
import java.awt.event.*;
class Demo extends Frame implements ActionListener {
    Button b1, b2, b3, b4;
    TextField t1,t2;
    Demo() {
        b1 = new Button("Green");
        b2 = new Button("Red");
        b3 = new Button("Yellow");
        b4 = new Button("close");
        t1=new TextField(20);
        t2=new TextField(20);
        setSize(200, 200);
        setVisible(true);
        setBackground(Color.MAGENTA);
        setLayout(new FlowLayout());
        add(b1);
        add(b2);
        add(b3);
        add(b4);
        add(t1);
        add(t2);
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
    }

    public void actionPerformed(ActionEvent ae) {
        // handle button clicks here
        if(ae.getSource()==b1){
            setBackground(Color.green);
        }
        if(ae.getSource()==b2){
            setBackground(Color.red);
        }
        if(ae.getSource()==b3){
            setBackground(Color.yellow);
        }
        if(ae.getSource()==b4){
            dispose();
        }
    }
}
public class gui {
    public static void main(String[] args) {
        Demo obj=new Demo();
    }
}