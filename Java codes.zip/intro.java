import java.util.Scanner;

class intro{
    public static void main(String[] args) {
        Scanner obj =new Scanner(System.in);
        String a;
        a=obj.nextLine();
        System.out.println("Name is : "+a); 
        obj.close();  
    }
}